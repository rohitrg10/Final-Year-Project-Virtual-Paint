import cv2
import numpy as np
import time
import os
import mediapipe as mp
import math
from cvzone.HandTrackingModule import HandDetector


class DragShape():
    def __init__(self,posOrigin,size=[150,150],isShape=None,radius = 100,color = (255,255,255),poly1=[0,0],ecli=[150,100],tri1=[0,0]):
        self.posOrigin=posOrigin
        self.size = size
        self.isShape=isShape
        self.radius=radius
        self.color = color
        self.poly1=poly1
        self.ecli=ecli
        self.tri1=tri1
        self.arrow1=[100,100]
        self.diamond1=[100,100]
        self.five_side=[100,100]
        self.six_side=[100,100]
        self.star1=[100,100]
        self.star2=[100,100]

    def update(self, cursor,drawColor):
        ox, oy = self.posOrigin
        if self.isShape=='circle':
            self.size=100,100
        h, w = self.size

        # Check if in region
        if ox < cursor[0] < ox + w and oy < cursor[1] < oy + h:
            self.posOrigin = cursor[0] - w//2 , cursor[1] - h//2
            self.color=drawColor

    def zoom(self,cursor,scale):
        ox, oy = self.posOrigin

        h, w = self.size

        if ox < cursor[0] < ox + w and oy < cursor[1] < oy + h:
            h1, w1= self.size
            #print(scale)
            if scale <10:
                newH, newW = ((h1 - scale) // 2) * 2, ((w1 - scale) // 2) * 2
                #print(newH,newW)
            else:
                newH, newW = ((h1 + scale) // 2) * 2, ((w1 + scale) // 2) * 2
            try:
                if newH>250 and newW>250:
                    pass
                if newH<100 and newW<100:
                    pass
                if 100<=newH<250 and 100<=newW<250:
                    if self.isShape == 'circle':
                        self.radius = scale * 7
                    elif self.isShape == 'polygon':
                        self.poly1=scale*2,scale*2
                    elif self.isShape=='eclipse':
                        self.ecli=scale*2+100,scale*2
                    elif self.isShape=='triangle':
                        self.tri1=scale*2,scale*2
                    elif self.isShape=='arrow':
                        self.arrow1=scale*2,scale*2
                    elif self.isShape=='diamond':
                        self.diamond1=scale*2,scale*2
                    elif self.isShape=='five_side':
                        self.five_side=scale*2,scale*2
                    elif self.isShape=='six_side':
                        self.six_side=scale*2,scale*2
                    elif self.isShape=='star1':
                        self.star1=scale*2,scale*2
                    elif self.isShape=='star2':
                        self.star2=scale*2,scale*2
                    elif self.isShape=='rect':
                        self.size = newW, newH
            except:
                pass