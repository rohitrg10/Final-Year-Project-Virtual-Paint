import cv2
import numpy as np
import time
import os
import HandTrackingModule as HT
import Pattern as pt
import Drag as DT

def Draw_shapes(listImg,img,pattern):
    for rect1 in listImg:
        if rect1.isShape == 'arrow':
            startPoint = rect1.posOrigin[0], rect1.posOrigin[1]
            endPoint = rect1.arrow1
            points = pattern.Right_arrow(startPoint, endPoint)
            cv2.fillPoly(img, pts=[points], color=rect1.color)

        elif rect1.isShape == 'diamond':
            startPoint = rect1.posOrigin[0], rect1.posOrigin[1]
            endPoint = rect1.diamond1
            points = pattern.Diamond(startPoint, endPoint)
            cv2.fillPoly(img, pts=[points], color=rect1.color)

        elif rect1.isShape == 'rect':
            cx, cy = rect1.posOrigin[0], rect1.posOrigin[1]
            w, h = rect1.size
            cv2.rectangle(img, (cx - w // 2, cy - h // 2),
                          (cx + w // 2, cy + h // 2), rect1.color, cv2.FILLED)

        elif rect1.isShape == 'triangle':
            cx, cy = rect1.posOrigin[0], rect1.posOrigin[1]
            w, h = rect1.size
            x, y = rect1.tri1
            pt1 = (cx, cy)
            pt2 = (cx - 50, cy + 100 + y)
            pt3 = (cx + 50 + x, cy + 100 + y)
            triangle_cnt = np.array([pt1, pt2, pt3])
            cv2.drawContours(img, [triangle_cnt], 0, rect1.color, -1)

        elif rect1.isShape == 'five_side':
            startPoint = rect1.posOrigin[0], rect1.posOrigin[1]
            endPoint = rect1.five_side
            points = pattern.Polygon_Five(startPoint, endPoint)
            cv2.fillPoly(img, pts=[points], color=rect1.color)

        elif rect1.isShape == 'six_side':
            startPoint = rect1.posOrigin[0], rect1.posOrigin[1]
            endPoint = rect1.six_side
            points = pattern.Polygon_Six(startPoint, endPoint)
            cv2.fillPoly(img, pts=[points], color=rect1.color)

        elif rect1.isShape == 'eclipse':
            cx, cy = rect1.posOrigin[0], rect1.posOrigin[1]
            w, h = rect1.size
            a, b = rect1.ecli
            center = cx, cy
            axes = a, b
            angle = 15
            cv2.ellipse(img, center, axes, angle, 0, 360, rect1.color, cv2.FILLED)

        elif rect1.isShape == 'star1':
            startPoint = rect1.posOrigin[0], rect1.posOrigin[1]
            endPoint = rect1.star1
            points = pattern.star(startPoint, endPoint)
            cv2.fillPoly(img, pts=[points], color=rect1.color)

        elif rect1.isShape == 'star2':
            startPoint = rect1.posOrigin[0], rect1.posOrigin[1]
            endPoint = rect1.star2
            points = pattern.Star_six(startPoint, endPoint)
            cv2.fillPoly(img, pts=[points], color=rect1.color)

        elif rect1.isShape == 'circle':
            cx, cy = rect1.posOrigin[0], rect1.posOrigin[1]
            w, h = rect1.size
            cv2.circle(img, (cx + w // 2, cy + h // 2), rect1.radius, rect1.color, cv2.FILLED)


def main():
    header = cv2.imread(f"Img.png")
    header1=cv2.imread(f"Img4.png")
    #cv2.imshow("jei",header)
    cap = cv2.VideoCapture(0)
    cap.set(3, 1280)
    cap.set(4, 720)
    brushThickness = 5
    pattern = pt.Pattern()
    eraserThickness = 100
    drawColor = (255, 0, 255)
    xp, yp = 0, 0
    mylist = []
    ox, oy = 300, 300
    listImg = []
    path2 = False
    imgCanvas = np.zeros((720, 1280, 3), np.uint8)
    detector = HT.HandDetector(detectionCon=0.8, maxHands=2)
    x = 1
    a = False
    save = False
    b12 = False
    y3 = 0
    p1 = False

    arrow = False
    diamond = False
    rect = False
    triangle = False

    five_side = False
    six_side = False
    eclipse = False

    star1 = False
    star2 = False

    increase_size = False
    decrease_size = False

    polygon = False
    circle = False
    while True:

        # 1. Import image
        success, img = cap.read()
        img = cv2.flip(img, 1)
        hands, img = detector.findHands(img, count=1)
        if hands:
            hand1 = hands[0]
            lmList1 = hand1["lmList"]
            handType1 = hand1["type"]
            x1, y1 = lmList1[8][0:2]
            x2, y2 = lmList1[12][0:2]
            fingers1 = detector.fingersUp(hand1)

            if len(hands) == 2:
                # Hand 2
                hand2 = hands[1]
                lmList2 = hand2["lmList"]
                handType2 = hand2["type"]
                x1, y1 = lmList2[8][0:2]
                x2, y2 = lmList2[12][0:2]
                fingers2 = detector.fingersUp(hand2)

            # 4. If Selection Mode - Two finger are up
            if fingers1[1] and fingers1[2]:
                # xp, yp = 0, 0
                # print("Selection Mode")
                # # Checking for the click
                if 35 < y1 < 110:
                    if 20 < x1 < 70:
                        drawColor = (0, 255, 0)
                    elif 124 < x1 < 190:
                        drawColor = (255, 0, 255)
                    elif 240 < x1 < 290:
                        drawColor = (255, 0, 0)
                    elif 340 < x1 < 400:
                        drawColor = (0, 0, 255)
                    elif 445 < x1 < 510:
                        drawColor = (0, 0, 0)

                    elif 560 < x1 < 620:
                        if decrease_size == False:
                            if brushThickness > 1:
                                brushThickness -= 1
                                decrease_size = True
                                print(brushThickness)
                    elif 665 < x1 < 730:
                        if increase_size == False:
                            if brushThickness < 15:
                                brushThickness += 2
                                increase_size = True
                                print(brushThickness)

                    elif 779 < x1 < 870:
                        drawColor = (255, 0, 0)
                        mylist.append('arrow')
                        arrow = True
                        a = True
                        path2 = True

                    elif 920 < x1 < 980:
                        drawColor = (0, 0, 0)
                        mylist.append('star2')
                        star2 = True
                        a = True
                        path2 = True

                    elif 1030 < x1 < 1120:
                        drawColor = (255, 0, 255)
                        eclipse = True
                        mylist.append('eclipse')
                        a = True
                        path2 = True

                    elif 1170 < x1 < 1260:
                        save = True
                        drawColor = (0, 0, 0)
                if 10 < x1 < 80:
                    if 140 < y1 < 180:
                        drawColor = (255, 255, 255)
                        mylist.append('diamond')
                        diamond = True
                        a = True
                        path2 = True
                    elif 215 < y1 < 250:
                        drawColor = (0,0,128)
                        mylist.append('rect')
                        rect = True
                        a = True
                        path2 = True
                    elif 295 < y1 < 335:
                        drawColor = (128,0,128)
                        mylist.append('six_side')
                        six_side = True
                        a = True
                        path2 = True
                    elif 385 < y1 < 440:
                        drawColor = (128,128,0)
                        mylist.append('circle')
                        circle = True
                        a = True
                        path2 = True
                    elif 480 < y1 < 520:
                        drawColor = (0, 165, 255)
                    elif 555 < y1 < 600:
                        drawColor = (0, 255, 255)
                    elif 635 < y1 < 680:
                        drawColor = (144, 238, 144)

                elif y1 > 125:
                    increase_size = False
                    decrease_size = False
                cv2.rectangle(img, (x1, y1 - 25), (x2, y2 + 25), drawColor, cv2.FILLED)

            if fingers1[1]:
                if not fingers1[0] and not fingers1[2]:
                    if fingers1[1] == True:
                        cv2.circle(img, (x1, y1), 15, drawColor, cv2.FILLED)
                        # print("Drawing Mode")
                        if xp == 0 and yp == 0:
                            xp, yp = x1, y1

                        cv2.line(img, (xp, yp), (x1, y1), drawColor, brushThickness)
                        if drawColor == (0, 0, 0):
                            cv2.line(img, (xp, yp), (x1, y1), drawColor, eraserThickness)
                            cv2.line(imgCanvas, (xp, yp), (x1, y1), drawColor, eraserThickness)
                        else:
                            cv2.line(img, (xp, yp), (x1, y1), drawColor, brushThickness)
                            cv2.line(imgCanvas, (xp, yp), (x1, y1), drawColor, brushThickness)
            xp, yp = x1, y1
            if (fingers1[0] and fingers1[1]):
                try:
                    lmList = hands[0]['lmList']
                    length, info, img = detector.findDistance([lmList[4][0], lmList[4][1]],
                                                              [lmList[8][0], lmList[8][1]], img)
                    pat1 = 'Img'
                    x = 1
                    if path2 and a:
                        if rect:
                            r = DT.DragShape([50 + x * 450, 300], isShape='rect')
                            listImg.append(r)
                            rect = False

                        elif circle:
                            r = DT.DragShape([50 + x * 450, 300], isShape='circle')
                            listImg.append(r)
                            circle = False

                        elif polygon:
                            r = DT.DragShape([50 + x * 450, 300], isShape='polygon')
                            listImg.append(r)
                            polygon = False

                        elif eclipse:
                            r = DT.DragShape([50 + x * 450, 300], isShape='eclipse')
                            listImg.append(r)
                            eclipse = False

                        elif triangle:
                            r = DT.DragShape([50 + x * 450, 300], isShape='triangle')
                            listImg.append(r)
                            triangle = False

                        elif arrow:
                            r = DT.DragShape([50 + x * 450, 300], isShape='arrow')
                            listImg.append(r)
                            arrow = False

                        elif diamond:
                            r = DT.DragShape([50 + x * 450, 300], isShape='diamond')
                            listImg.append(r)
                            diamond = False

                        elif five_side:
                            r = DT.DragShape([50 + x * 450, 300], isShape='five_side')
                            listImg.append(r)
                            five_side = False

                        elif six_side:
                            r = DT.DragShape([50 + x * 450, 300], isShape='six_side')
                            listImg.append(r)
                            six_side = False

                        elif star1:
                            r = DT.DragShape([50 + x * 450, 300], isShape='star1')
                            listImg.append(r)
                            star1 = False

                        elif star2:
                            r = DT.DragShape([50 + x * 450, 300], isShape='star2')
                            listImg.append(r)
                            star2 = False
                        a = False

                    if length <= 50:
                        cursor = lmList[4]
                        for imgObject in listImg:
                            imgObject.update(cursor, drawColor)

                    elif length > 50:
                        cursor = lmList[4]
                        scale = int(np.interp(length, [50, 300], [0, 60]))
                        for imgObject in listImg:
                            imgObject.zoom(cursor, scale)
                except:
                    pass

        '''if drawColor == (0, 0, 0):
            cv2.line(img, (xp, yp), (x1, y1), drawColor, eraserThickness)'''
        # cv2.line(imgCanvas, (xp, yp), (x1, y1), drawColor, eraserThickness)

        Draw_shapes(listImg,img,pattern)

        if save:
            Draw_shapes(listImg, imgCanvas, pattern)

        if len(hands) == 2:
            if detector.fingersUp(hands[0]) == [1, 1, 0, 0, 0] and detector.fingersUp(hands[1]) == [1, 1, 0, 0, 0]:
                lmList1 = hands[0]["lmList"]
                lmList2 = hands[1]["lmList"]

                length, info = detector.findDistance([lmList1[8][0], lmList1[8][1]], [lmList1[2][0], lmList1[2][1]],
                                                     )
                length1, info1 = detector.findDistance([lmList1[2][0], lmList1[2][1]], [lmList2[2][0], lmList2[2][1]],
                                                       )
                length2, info2 = detector.findDistance([lmList2[2][0], lmList2[2][1]], [lmList2[8][0], lmList2[8][1]],
                                                       )
                length3, info3 = detector.findDistance([lmList2[8][0], lmList2[8][1]], [lmList1[8][0], lmList1[8][1]],
                                                       )
                x3 = info3[0]
                x4 = info1[0]
                y3 = info3[1]
                y4 = info1[1]
                cv2.rectangle(img, (x3, y3),
                              (x4, y4), (0, 255, 0), 2)
                b12 = True
        if b12 and y1 != 0:
            if y3 == y4 or x3 == x4:
                pass
            if x3 > x4:
                roi = imgCanvas[y3:y4, x4:x3]
            else:
                roi = imgCanvas[y3:y4, x3:x4]
            p1 = True

        imgGray = cv2.cvtColor(imgCanvas, cv2.COLOR_BGR2GRAY)
        _, imgInv = cv2.threshold(imgGray, 50, 255, cv2.THRESH_BINARY_INV)
        imgInv = cv2.cvtColor(imgInv, cv2.COLOR_GRAY2BGR)
        img = cv2.bitwise_and(img, imgInv)
        img = cv2.bitwise_or(img, imgCanvas)

        img[0:125, 0:1280] = header
        img[125:705, 0:100] = header1
        cv2.imshow("Image", img)
        if save:
            cv2.imwrite("b.png", imgCanvas)
        if cv2.waitKey(1):
            if p1 and save:
                r12 = cv2.imread("b.png")
                if x3 > x4:
                    roi = r12[y3:y4, x4:x3]
                else:
                    roi = r12[y3:y4, x3:x4]

                cv2.imwrite("bx.png", roi)


if __name__ =='__main__':
    main()