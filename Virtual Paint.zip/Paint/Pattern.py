import numpy as np
class Pattern:
    def Right_arrow(self,startPoint,endPoint):
        a,b = endPoint[0],endPoint[1]

        A= (int(startPoint[0]), int(a / 2 + startPoint[1]))
        B = (int(startPoint[0] + 4 * b / 3), int(a / 2 + startPoint[1]))
        C = (int(startPoint[0] + 4 * b / 3), int(startPoint[1]))
        D = (int(startPoint[0]), int(3 * a / 2 + startPoint[1]))
        E = (int(startPoint[0] + 4 * b / 3), int(3 * a / 2 + startPoint[1]))
        F = (int(startPoint[0] + 4 * b / 3), int(2 * a + startPoint[1]))
        G = (int(startPoint[0] + 2 * b), int(a + startPoint[1]))

        points = np.array([[A, B], [B, C], [C, G],
                           [A,D],[D,E],[E,F],[F,G]], np.int32)
        points = points.reshape((-1, 1, 2))
        return points

    def Diamond(self,startPoint,endPoint):
        a,b = endPoint[0],endPoint[1]

        A= (int(startPoint[0] + b), int(startPoint[1]))
        B = (int(startPoint[0]), int(startPoint[1] + a))
        C = (int(startPoint[0] + b), int(int(startPoint[1]) + 2 * a))
        D = (int(startPoint[0] + 2 * b), int(startPoint[1] + a))

        points = np.array([[A, B], [B, C], [C, D],
                           [D,A]], np.int32)
        points = points.reshape((-1, 1, 2))
        return points

    def triangle(self,startPoint,endPoint):
        a,b = endPoint[0],endPoint[1]

        A = (int(startPoint[0]), int(endPoint[1]))
        B = (int(endPoint[0]), int(endPoint[1]))
        C = (int(startPoint[0] + b), int(startPoint[1]))

        points = np.array([[A, B], [B, C], [C, A]], np.int32)
        points = points.reshape((-1, 1, 2))
        return points

    def Polygon_Five(self,startPoint,endPoint):
        a,b = endPoint[0],endPoint[1]

        A = (int(startPoint[0] + b), int(startPoint[1]))
        B = (int(startPoint[0]), int(startPoint[1] + a))
        C = (int(startPoint[0] + b / 2), int(int(startPoint[1]) + 2 * a))
        D = (int(startPoint[0] + 3 * b / 2), int(startPoint[1] + 2 * a))
        E = (int(startPoint[0] + 2 * b), int(startPoint[1] + a))

        points = np.array([[A, B], [B, C], [C, D],[D,E],[E,A]], np.int32)
        points = points.reshape((-1, 1, 2))
        return points

    def Polygon_Six(self,startPoint,endPoint):
        a, b = endPoint[0], endPoint[1]

        A = (int(startPoint[0] + b), int(startPoint[1]))
        B = (int(startPoint[0]), int(startPoint[1] + a / 2))
        C = (int(startPoint[0]), int(int(startPoint[1]) + 3 * a / 2))
        D = (int(startPoint[0] + b), int(startPoint[1] + 2 * a))
        E = (int(startPoint[0] + 2 * b), int(startPoint[1] + 3 * a / 2))
        F = (int(startPoint[0] + 2 * b), int(startPoint[1] + a / 2))

        points = np.array([[A, B], [B, C], [C, D], [D, E], [E, F],[F,A]], np.int32)
        points = points.reshape((-1, 1, 2))
        return points

    def star(self,startPoint,endPoint):
        a,b = endPoint[0], endPoint[1]

        A = (int(startPoint[0] + b), int(startPoint[1]))
        A1 = (int(startPoint[0] + 3 * b / 4), int(startPoint[1] + 3 * a / 4))
        A2 = (int(startPoint[0]), int(0.8 * a + startPoint[1]))
        A3 = (int(startPoint[0] + b * 0.65), int(startPoint[1] + 1.25 * a))
        A4 = (int(startPoint[0] + b / 2), int(startPoint[1] + 2 * a))

        B = (int(startPoint[0] + b), int(1.25 * a + startPoint[1]))
        B1 = (int(startPoint[0] + 1.5 * b), int(2 * a + startPoint[1]))
        B2 = (int(startPoint[0] + 1.35 * b), int(1.25 * a + startPoint[1]))
        B3 = (int(startPoint[0] + 2 * b), int(0.8 * a + startPoint[1]))
        B4 = (int(startPoint[0] + 1.25 * b), int(3 * a / 4 + startPoint[1]))

        points = np.array([[A, A1], [A1, A2],
                         [A2, A3], [A3, A4],
                         [A4, B], [B, B1],
                         [A, B4], [B4, B3],
                         [B3, B2], [B1, B2]
                         ], np.int32)
        points = points.reshape((-1, 1, 2))
        return points

    def Star_six(self,startPoint,endPoint):
        a, b = endPoint[0], endPoint[1]

        A = (int(startPoint[0] + b), int(startPoint[1]))
        B = (int(startPoint[0] + 3 * b / 4), int(startPoint[1] + a / 2))
        C = (int(startPoint[0]), int(int(startPoint[1]) + a / 2))
        D = (int(startPoint[0] + b / 2), int(startPoint[1] + a))
        E = (int(startPoint[0]), int(startPoint[1] + 1.5 * a))
        F = (int(startPoint[0] + 3 * b / 4), int(startPoint[1] + 1.5 * a))
        G = (int(startPoint[0] + b), int(startPoint[1] + 2 * a))
        H = (int(startPoint[0] + 1.25 * b), int(startPoint[1] + 1.5 * a))
        I = (int(startPoint[0] + 2 * b), int(startPoint[1] + 1.5 * a))
        J = (int(startPoint[0] + 1.5 * b), int(startPoint[1] + a))
        K = (int(startPoint[0] + 2 * b), int(startPoint[1] + a / 2))
        L = (int(startPoint[0] + 1.25 * b), int(startPoint[1] + a / 2))

        points = np.array([[A, B], [B, C], [C, D],
                           [D, E], [E, F], [F, G],
                           [G, H], [H, I], [I, J],
                           [J, K], [K, L], [L, A]],
                          np.int32)
        points = points.reshape((-1, 1, 2))
        return points








